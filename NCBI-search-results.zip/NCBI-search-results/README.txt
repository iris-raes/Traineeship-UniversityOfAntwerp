.csv files can be opened in Excel.

All column names and values are separated by a semicolon (';').

Make sure that the delimiter in Excel is set correctly:
	1. Go to 'Configuratiescherm > 'Klok en regio' 
	2. Click on 'Land/regio', 'Meer instellingen...'
	3. Check 'Lijstscheidingsreken'. If necessary, adjust to ';'.
